<?php

declare(strict_types=1);

use GuzzleHttp\Client;

/**
 * Standalone utility to fetch Compliance and Production CSIDs from ZATCA.
 *
 * This file is intentionally independent from existing application classes.
 */
class ZatcaCsidAutoFetcher
{
    private const DEFAULT_API_BASE = 'https://gw-fatoora.zatca.gov.sa/e-invoicing/developer-portal/';

    /** @var Client */
    private $httpClient;

    /** @var string */
    private $apiBase;

    public function __construct(string $apiBase = self::DEFAULT_API_BASE, int $timeoutSeconds = 45)
    {
        $this->apiBase = self::normalizeApiBase($apiBase);
        $this->httpClient = new Client([
            'base_uri' => $this->apiBase,
            'timeout' => $timeoutSeconds,
            'http_errors' => false,
        ]);
    }

    /**
     * Fetch Compliance CSID using OTP + CSR, then Production CSID automatically.
     *
     * @return array<string,mixed>
     */
    public function fetchAll(string $otp, string $csrInput): array
    {
        $compliance = $this->requestComplianceCsid($otp, $csrInput);

        if (empty($compliance['success'])) {
            return [
                'success' => false,
                'stage' => 'compliance',
                'api_base' => $this->apiBase,
                'compliance' => $compliance,
                'production' => null,
            ];
        }

        $production = $this->requestProductionCsid(
            (string) ($compliance['binary_security_token'] ?? ''),
            (string) ($compliance['secret'] ?? ''),
            (string) ($compliance['request_id'] ?? '')
        );

        if (empty($production['success'])) {
            return [
                'success' => false,
                'stage' => 'production',
                'api_base' => $this->apiBase,
                'compliance' => $compliance,
                'production' => $production,
            ];
        }

        return [
            'success' => true,
            'stage' => 'completed',
            'api_base' => $this->apiBase,
            'compliance' => $compliance,
            'production' => $production,
            'keys' => [
                'zatca_binary_security_token' => (string) ($compliance['binary_security_token'] ?? ''),
                'zatca_secret' => (string) ($compliance['secret'] ?? ''),
                'zatca_compliance_request_id' => (string) ($compliance['request_id'] ?? ''),
                'zatca_production_binary_security_token' => (string) ($production['binary_security_token'] ?? ''),
                'zatca_production_secret' => (string) ($production['secret'] ?? ''),
                'zatca_production_request_id' => (string) ($production['request_id'] ?? ''),
            ],
        ];
    }

    /**
     * @return array<string,mixed>
     */
    public function requestComplianceCsid(string $otp, string $csrInput): array
    {
        $otp = trim($otp);
        $csr = self::normalizeCsr($csrInput);

        if ($otp === '') {
            return [
                'success' => false,
                'status_code' => 0,
                'message' => 'OTP is required.',
                'response_body' => '',
            ];
        }

        if ($csr === '') {
            return [
                'success' => false,
                'status_code' => 0,
                'message' => 'CSR is missing or invalid.',
                'response_body' => '',
            ];
        }

        try {
            $response = $this->httpClient->post('compliance', [
                'headers' => [
                    'Accept' => 'application/json',
                    'Accept-Language' => 'en',
                    'Accept-Version' => 'V2',
                    'Content-Type' => 'application/json',
                    'OTP' => $otp,
                ],
                'json' => [
                    'csr' => $csr,
                ],
            ]);

            return $this->mapComplianceResponse($response->getStatusCode(), (string) $response->getBody());
        } catch (Throwable $e) {
            return [
                'success' => false,
                'status_code' => 0,
                'message' => 'Compliance request failed: ' . $e->getMessage(),
                'response_body' => '',
            ];
        }
    }

    /**
     * @return array<string,mixed>
     */
    public function requestProductionCsid(
        string $complianceToken,
        string $complianceSecret,
        string $complianceRequestId
    ): array {
        $complianceToken = preg_replace('/\s+/', '', trim($complianceToken));
        $complianceSecret = trim($complianceSecret);
        $complianceRequestId = trim($complianceRequestId);

        if ($complianceToken === '' || $complianceSecret === '') {
            return [
                'success' => false,
                'status_code' => 0,
                'message' => 'Compliance token and secret are required for production CSID request.',
                'response_body' => '',
            ];
        }

        if ($complianceRequestId === '') {
            return [
                'success' => false,
                'status_code' => 0,
                'message' => 'Compliance request ID is required for production CSID request.',
                'response_body' => '',
            ];
        }

        try {
            $response = $this->httpClient->post('production/csids', [
                'headers' => [
                    'Accept' => 'application/json',
                    'Accept-Language' => 'en',
                    'Accept-Version' => 'V2',
                    'Authorization' => 'Basic ' . base64_encode($complianceToken . ':' . $complianceSecret),
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'compliance_request_id' => $complianceRequestId,
                ],
            ]);

            return $this->mapProductionResponse($response->getStatusCode(), (string) $response->getBody());
        } catch (Throwable $e) {
            return [
                'success' => false,
                'status_code' => 0,
                'message' => 'Production request failed: ' . $e->getMessage(),
                'response_body' => '',
            ];
        }
    }

    /**
     * @return array<string,mixed>
     */
    private function mapComplianceResponse(int $statusCode, string $responseBody): array
    {
        $decoded = json_decode($responseBody, true);
        if (!is_array($decoded)) {
            $decoded = [];
        }

        $token = isset($decoded['binarySecurityToken']) ? trim((string) $decoded['binarySecurityToken']) : '';
        $secret = isset($decoded['secret']) ? trim((string) $decoded['secret']) : '';
        $requestId = isset($decoded['requestID']) ? trim((string) $decoded['requestID']) : '';

        if ($statusCode >= 200 && $statusCode < 300 && $token !== '' && $secret !== '') {
            return [
                'success' => true,
                'status_code' => $statusCode,
                'message' => 'Compliance CSID fetched successfully.',
                'response_body' => $responseBody,
                'binary_security_token' => $token,
                'secret' => $secret,
                'request_id' => $requestId,
            ];
        }

        return [
            'success' => false,
            'status_code' => $statusCode,
            'message' => 'Compliance CSID request failed with status code ' . $statusCode,
            'response_body' => $responseBody,
        ];
    }

    /**
     * @return array<string,mixed>
     */
    private function mapProductionResponse(int $statusCode, string $responseBody): array
    {
        $decoded = json_decode($responseBody, true);
        if (!is_array($decoded)) {
            $decoded = [];
        }

        $token = isset($decoded['binarySecurityToken']) ? trim((string) $decoded['binarySecurityToken']) : '';
        $secret = isset($decoded['secret']) ? trim((string) $decoded['secret']) : '';
        $requestId = isset($decoded['requestID']) ? trim((string) $decoded['requestID']) : '';

        if ($statusCode >= 200 && $statusCode < 300 && $token !== '' && $secret !== '') {
            return [
                'success' => true,
                'status_code' => $statusCode,
                'message' => 'Production CSID fetched successfully.',
                'response_body' => $responseBody,
                'binary_security_token' => $token,
                'secret' => $secret,
                'request_id' => $requestId,
            ];
        }

        return [
            'success' => false,
            'status_code' => $statusCode,
            'message' => 'Production CSID request failed with status code ' . $statusCode,
            'response_body' => $responseBody,
        ];
    }

    private static function normalizeApiBase(string $apiBase): string
    {
        $apiBase = trim($apiBase);
        if ($apiBase === '') {
            $apiBase = self::DEFAULT_API_BASE;
        }

        return rtrim($apiBase, '/') . '/';
    }

    private static function normalizeCsr(string $csrInput): string
    {
        $raw = self::resolveTextValue($csrInput);
        $raw = trim($raw);

        if ($raw === '') {
            return '';
        }

        $decodedCandidate = base64_decode($raw, true);
        if ($decodedCandidate !== false && stripos($decodedCandidate, 'BEGIN CERTIFICATE REQUEST') !== false) {
            $raw = $decodedCandidate;
        }

        $raw = preg_replace('/-----BEGIN CERTIFICATE REQUEST-----/i', '', $raw);
        $raw = preg_replace('/-----END CERTIFICATE REQUEST-----/i', '', $raw);
        $raw = preg_replace('/\s+/', '', $raw);

        return trim((string) $raw);
    }

    private static function resolveTextValue(string $raw): string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return '';
        }

        if (is_file($raw) && is_readable($raw)) {
            $content = file_get_contents($raw);
            return $content === false ? '' : (string) $content;
        }

        return str_replace(["\\r\\n", "\\n"], ["\n", "\n"], $raw);
    }
}
